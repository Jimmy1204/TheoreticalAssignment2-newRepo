package Jimmy;

public class ATM 
{
	private boolean userAuthenticated;
	private int currentAccountNumber;
	private Screen screen;
	private Keypad keypad;
	private CashDispenser cashDispenser;
	private DepositSlot depositSlot;
	private BankDatabase bankDatabase;
	private static final int BALANCE_INQUIRY = 1;
	private static final int WITHDRAWAL = 2;
	private static final int DEPOSIT = 3;
	private static final int EXIT = 4;
	
	public ATM()
	{
		userAuthenticated = false;
		currentAccountNumber = 0;
		screen = new Screen();
		screen.showScreen();
		keypad = new Keypad();
		cashDispenser = new CashDispenser();
		depositSlot = new DepositSlot();
		bankDatabase = new BankDatabase();
	}
	
	public void run()
	{
		while(true)
		{
			while(!userAuthenticated)
			{
				screen.displayMessageLine("\nWelcome!");
				authenticateUser();
			}
			performTransactions();
			userAuthenticated = false;
			currentAccountNumber = 0;
			screen.displayMessageLine("\nThank you! Goodbye!");
			
		}
	}
	
	private void authenticateUser()
	{
		screen.displayMessage("\nPlease enter your account number: ");
		int accountNumber=0;
		while(screen.flag!=1)
		{
			try 
			{
				Thread.sleep(1000);
			} catch (InterruptedException e) 
			{
			// TODO Auto-generated catch block
			e.printStackTrace();
			}//keypad.getInput();
		}
		accountNumber= screen.name;
		screen.flag=0;
		screen.displayMessage("\nEnter your PIN: ");
		int pin = 0;
		while(screen.flag!=1)
		{
			try 
			{
				Thread.sleep(1000);
			} catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		pin = screen.password;
		screen.flag=0;
		userAuthenticated = 
				bankDatabase.authenticateUser(accountNumber, pin);
		if(userAuthenticated){
			currentAccountNumber = accountNumber;
		}
		else
			screen.displayMessageLine("Invalid account number or PIN. Please try again.");
		
	}
	
	private void performTransactions()
	{
		Transaction currentTransaction = null;
		boolean userExited = false;
		while(!userExited)
		{
			int mainMenuSelection = displayMainMenu();
			switch(mainMenuSelection){
			case BALANCE_INQUIRY:
			case WITHDRAWAL:
			case DEPOSIT:
				
			System.out.println(mainMenuSelection);
			currentTransaction = 
					createTransaction(mainMenuSelection);
			currentTransaction.execute();
				break;
				
			case EXIT:
			screen.displayMessageLine("\nExiting the system...");
			userExited = true;
				break;
				
			default:
				screen.displayMessageLine(
						"\nYou did not enter a valid selection. Try again.");
				break;
			}
		}
	}
	
	private int displayMainMenu(){
		screen.displayMessageLine("\nMain menu:");
		screen.displayMessageLine("\n1 - View my balance");
		screen.displayMessageLine("\n2 - Withdraw cash");
		screen.displayMessageLine("\n3 - Deposit funds");
		screen.displayMessageLine("\n4 - Exit\n");
		screen.displayMessage("\nEnter a choice: ");
		while(screen.flag!=1){
			 
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//keypad.getInput();
		}
		screen.flag=0;
		return screen.choice;//keypad.getInput();
	}
	
	private Transaction createTransaction(int type)
	{
		Transaction temp = null;
		switch(type)
		{
		case BALANCE_INQUIRY:
			temp = new BalanceInquiry(
					currentAccountNumber, screen, bankDatabase);
			break;
		case WITHDRAWAL:
			temp = new Withdrawal(currentAccountNumber, screen,
					 bankDatabase, keypad, cashDispenser);
			break;
		case DEPOSIT:
			temp = new Deposit(currentAccountNumber,screen,bankDatabase,keypad,depositSlot);
			break;
		}
		
		return temp;
	}
	
	
	
}
