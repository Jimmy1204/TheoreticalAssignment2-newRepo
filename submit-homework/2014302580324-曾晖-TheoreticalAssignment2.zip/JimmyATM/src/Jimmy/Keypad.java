package Jimmy;
import java.util.Scanner;

public class Keypad {
	private Scanner input;
	public int i;
	public int getI() {
		
		return i;
	}

	public void setI(String s) {
		
		this.i = Integer.parseInt(s);
	}

	public Keypad()
	{
		input = new Scanner(System.in);
		
	}
	
	public int getInput()
	{
		
		return i;
	}
}
