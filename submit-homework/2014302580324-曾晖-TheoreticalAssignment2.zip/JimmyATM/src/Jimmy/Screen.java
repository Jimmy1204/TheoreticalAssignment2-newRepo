package Jimmy;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Screen extends JFrame implements ActionListener
{
	private JTextArea textarea;//���뼰������
	ImageIcon icon = new ImageIcon("src\\Jimmy\\1.jpg");//ȡ���ͼƬ
	JLabel l1 = new JLabel("       ");//����ͼƬ�ı�ǩ
	
	public int flag = 0;
	private Screen screen;
	public int action = 1;
	public int name;
	public int password;
	public int choice = 0;
	
	private final String[] s = {"0","1","2","3","4","5","6","7","8","9","ȷ��","�˳�"};//�����ַ�������
	
	//��ʾ����
	public void showScreen()
	{
		screen=new Screen();
		screen.setLayout(new GridLayout(1,1,20,20));//���в���
		screen.setSize(800, 1000);//���ڴ�С
		textarea=new JTextArea();
		l1.setIcon(icon);//����ͼƬ
		JButton[] button = new JButton[s.length];//��������
		JPanel panel=new JPanel(new GridLayout(3, 1,10,10));//�������񲼾�
		
		//���ְ�������������
		for (int i = 0; i < s.length; i++) 
		{
			button[i]=new JButton(s[i]);
			panel.add(button[i]);
			button[i].setActionCommand(s[i]);
			button[i].addActionListener(this);
			button[i].setBackground(Color.GREEN);
		}
		
		//��������
		screen.add(textarea);
		JPanel panel2 = new JPanel(new FlowLayout());
		panel2.add(l1);
		panel2.add(panel);
		screen.add(panel2);
		screen.setVisible(true);
	}		
	@Override
	
	//��ť�¼���Ӧ
	public void actionPerformed(ActionEvent e) 
	{
		// TODO Auto-generated method stub
		for(int i = 0;i < 10;i++)
		{
			if(e.getActionCommand().equals(s[i]))
			{
				displayMessage(s[i]+"");
			}
		}
		
		if(e.getActionCommand().equals("�˳�"))
		{
			System.exit(0);
		}
		
		if(e.getActionCommand().equals("ȷ��"))
		{
			if(action==2)
			{
				password=getInput();
				System.out.println(password);
				flag=1;
				textarea.setText("");
				action=3;
			}
			
			if(action==1)
			{
				name=getInput();
				System.out.println(name);
				flag=1;
				action=2;
			}
			
			if(action==3)
			{
				choice=getInput();
				flag=1;
				action=3;
			}
		}	
	}
	
	public int getInput()
	{
		String name1=textarea.getText().trim();
		String[] names = name1.split(":");
		String value = names[names.length-1].trim();
		int v=Integer.parseInt(value.trim());
		return v;
	}
	

	public void displayMessage(String message)
	{
		textarea.setText(textarea.getText()+message);
	}
	
	public void displayMessageLine(String message)
	{
		textarea.setText(textarea.getText()+message);
	}
	
	public void displayDollarAmount(double amount)
	{
		textarea.setText(textarea.getText()+" $"+amount);
	}

}
